jQuery(document).ready(function ($) {
    // Corrects rendering of the date picker
    function fixDatePicker() {
        var dateInput = $('input[name="work_notes_date"]');
        dateInput.focus();
        dateInput.blur();
    }

    // Render a row in the table (used for both add and update)
    function renderNoteRow(index, note) {
        return `
            <tr data-note-id="${index}">
                <td>${note.date}</td>
                <td>${note.content}</td>
                <td>
                    <button class="ui button blue edit-note" data-note-id="${index}">Edit</button>
                    <button class="ui button red delete-note" data-note-id="${index}">Delete</button>
                </td>
            </tr>`;
    }

    // Bind event handlers for dynamically inserted content
    function bindWorkNotesEvents() {
        // Edit note
        $(document).on('click', '.edit-note', function () {
            var noteId = $(this).data('note-id');
            var wpid = $('input[name="wpid"]').val();

            var data = {
                action: 'load_work_note',
                nonce: mainwpWorkNotes.nonce,
                wpid: wpid,
                note_id: noteId
            };

            $.post(mainwpWorkNotes.ajax_url, data, function (response) {
                if (response.success) {
                    $('input[name="note_id"]').val(noteId);
                    $('input[name="work_notes_date"]').val(response.data.date);

                    var editor = tinyMCE.get('work_notes_content');
                    if (editor && editor instanceof tinymce.Editor) {
                        editor.setContent(response.data.content);
                    } else {
                        $('textarea[name="work_notes_content"]').val(response.data.content);
                    }

                    fixDatePicker();
                } else {
                    alert(response.data.message);
                }
            });
        });

        // Delete note
        $(document).on('click', '.delete-note', function () {
            if (!confirm('Are you sure you want to delete this note?')) return;

            var noteId = $(this).data('note-id');
            var wpid = $('input[name="wpid"]').val();

            var data = {
                action: 'delete_work_note',
                nonce: mainwpWorkNotes.nonce,
                wpid: wpid,
                note_id: noteId
            };

            $.post(mainwpWorkNotes.ajax_url, data, function (response) {
                if (response.success) {
                    alert('Note deleted successfully!');
                    $('tr[data-note-id="' + noteId + '"]').remove();
                    resetForm();
                } else {
                    alert(response.data.message);
                }
            });
        });
    }

    // Reset form to initial state
    function resetForm() {
        $('input[name="note_id"]').val('-1');
        $('input[name="work_notes_date"]').val('');
        if (typeof tinyMCE !== 'undefined') {
            var editor = tinyMCE.get('work_notes_content');
            if (editor) {
                editor.setContent('');
            }
        }
        $('textarea[name="work_notes_content"]').val('');
        fixDatePicker();
    }

    // Handle saving a new or edited note
    $('#save-work-note').on('click', function () {
        var noteId = $('input[name="note_id"]').val();
        var wpid = $('input[name="wpid"]').val();
        var content = tinyMCE.get('work_notes_content') ? tinyMCE.get('work_notes_content').getContent() : $('textarea[name="work_notes_content"]').val();

        var data = {
            action: 'save_work_note',
            nonce: mainwpWorkNotes.nonce,
            wpid: wpid,
            note_id: noteId,
            work_notes_date: $('input[name="work_notes_date"]').val(),
            work_notes_content: content
        };

        $.post(mainwpWorkNotes.ajax_url, data, function (response) {
            if (response.success) {
                alert('Note saved successfully!');
                var tableBody = $('.ui.celled.table tbody');

                // Check if we are updating or creating
                var isEdit = (noteId !== '-1');

                if (isEdit) {
                    // Replace row content
                    $('tr[data-note-id="' + noteId + '"]').replaceWith(renderNoteRow(noteId, {
                        date: data.work_notes_date,
                        content: content
                    }));
                } else {
                    // New note - reload full list from backend OR insert new row
                    // Simplest way: just reload the page
                    // Better: append row and set its index
                    var newIndex = tableBody.find('tr').length;
                    tableBody.append(renderNoteRow(newIndex, {
                        date: data.work_notes_date,
                        content: content
                    }));
                }

                resetForm();
            } else {
                alert(response.data.message);
            }
        });
    });

    // Initial setup
    fixDatePicker();
    bindWorkNotesEvents();
    console.log("Work Notes JS Loaded V2");
});
