=== MainWP Client Notes Pro Report Extension ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: MainWP, ClientNotes, Pro-report
Requires at least: 6.5
Tested up to: 6.8.2
Stable tag: 1.2.5-beta.3
Requires PHP: 7.4
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Install on your dashboard within client sites you will now have a new area to add work notes and you can use them in your reports too.
== Description ==

Install on your dashboard within client sites you will now have a new area to add work notes and you can use them in your reports too.
== Installation ==

1. Upload the `mainwp-work-notes-proreports-extention` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the plugin settings it is located in the Simply Static Menu

== Frequently Asked Questions ==
 
== Changelog == 
1.2.5
New: Added Support for Preleases
New: Updated UUPD to 1.3.0

1.2.4 
- Added support for editing Work Notes using the WordPress visual editor (TinyMCE), enabling rich text formatting.
- Notes are now stored and displayed with HTML formatting, preserving line breaks, styling, and structure.
- Improved note editing logic to ensure existing notes (including index 0) are correctly updated instead of creating duplicates in HTML editor
- Update Plugin Description
1.23 - Update: UUPD - 1.25 & Improved: New Line Removal and Support for </br> - S Najman
1.22 - Scoped UUPD to make it unique to my plugins
1.21 - added language support on the notes display stable
added: dutch translation
added: support for client report extension < 4.0.15, needs the manual adding the token in client report admin
1.11 - V1.2 - Added automatic updates using GitHub to the plugin (Experimental)
Over the next week or so this will slowly increase to V1.2 as I test a new deploy script and updater for GitHub repos.
