=== MainWP Client Notes Pro Report Extension ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: MainWP, ClientNotes, Pro-report
Requires at least: 6.5
Tested up to: 6.8.1
Stable tag: 1.1.5
Requires PHP: 7.4
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Install on your dashboard and it will allow you to pull data from Cloudflare for your MainWP reports.
== Description ==

Install on your dashboard and it will allow you to pull data from Cloudflare for your MainWP reports.

== Installation ==

1. Upload the `mainwp-work-notes-proreports-extention` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the plugin settings it is located in the Simply Static Menu

== Frequently Asked Questions ==
 
== Changelog == 
1.11 - V1.2 - Added automatic updates using GitHub to the plugin (Experimental)
Over the next week or so this will slowly increase to V1.2 as I test a new deploy script and updater for GitHub repos.

